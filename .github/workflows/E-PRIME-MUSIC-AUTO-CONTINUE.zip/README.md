# E PRIME MUSIC Android

This project is configured to build an Android APK automatically with GitHub Actions.

## Upload to GitHub

1. Create a new GitHub repository (for example `e-prime-music-android`).
2. Extract this ZIP.
3. Upload **all files and folders inside the extracted project** to the repository root. The repository should contain `app/`, `build.gradle`, `settings.gradle`, and `.github/` at the top level.
4. Commit to the `main` branch.
5. Open the repository on GitHub and select **Actions**.
6. Open **Build E PRIME MUSIC APK**.
7. Wait for the workflow to finish with a green check.
8. Open the completed workflow run and scroll to **Artifacts**.
9. Download `E-PRIME-MUSIC-debug` and extract it to get `app-debug.apk`.

The workflow also has **Run workflow**, so you can manually rebuild the APK from the Actions page without making a new commit.

## What is included

- Android background playback service.
- Android media-session/notification controls for the current track.
- Nigerian/African search prioritization in the app search logic.
- GitHub Actions debug APK build.

## Important

This is a debug APK. For a Play Store/release APK, configure a signing key and a release workflow rather than distributing the debug build.
