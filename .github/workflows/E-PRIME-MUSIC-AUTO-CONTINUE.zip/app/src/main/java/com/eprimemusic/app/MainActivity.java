package com.eprimemusic.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.app.DownloadManager;
import java.lang.ref.WeakReference;

public class MainActivity extends Activity {
    private WebView webView;
    private static WeakReference<MainActivity> current;
    private static final int NOTIFICATION_REQUEST = 7001;
    private static final int STORAGE_REQUEST = 7002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = new WeakReference<>(this);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIFICATION_REQUEST);
        }
        if (Build.VERSION.SDK_INT < 29 &&
                checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, STORAGE_REQUEST);
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new MediaBridge(this), "EPrimeMedia");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme != null && (scheme.equals("http") || scheme.equals("https"))) {
                    view.loadUrl(uri.toString());
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    public static void mediaCommand(String action) {
        MainActivity a = current == null ? null : current.get();
        if (a == null || a.webView == null) return;
        a.runOnUiThread(() -> {
            String js;
            switch (action) {
                case "play": js = "window.eprimeMediaCommand('play')"; break;
                case "pause": js = "window.eprimeMediaCommand('pause')"; break;
                case "next": js = "window.eprimeMediaCommand('next')"; break;
                case "prev": js = "window.eprimeMediaCommand('prev')"; break;
                default: return;
            }
            a.webView.evaluateJavascript(js, null);
        });
    }

    private static class MediaBridge {
        private final Context context;
        MediaBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void update(String title, String artist, boolean playing) {
            Intent i = new Intent(context, MediaPlaybackService.class)
                    .setAction(MediaPlaybackService.ACTION_UPDATE)
                    .putExtra(MediaPlaybackService.EXTRA_TITLE, title)
                    .putExtra(MediaPlaybackService.EXTRA_ARTIST, artist)
                    .putExtra(MediaPlaybackService.EXTRA_PLAYING, playing);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
            else context.startService(i);
        }

        @JavascriptInterface
        public void download(String url, String fileName) {
            if (url == null || url.trim().isEmpty()) return;
            final String safeName = sanitizeFileName(fileName);
            new Thread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Audio.Media.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg");
                        values.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/E-Prime Music");
                        values.put(MediaStore.Audio.Media.IS_PENDING, 1);

                        Uri item = context.getContentResolver().insert(
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
                        if (item == null) throw new Exception("Could not create music file");

                        try {
                            downloadToUri(url, item);
                            ContentValues done = new ContentValues();
                            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
                            context.getContentResolver().update(item, done, null, null);
                            showToast("Saved to Music/E-Prime Music");
                        } catch (Exception e) {
                            context.getContentResolver().delete(item, null, null);
                            throw e;
                        }
                    } else {
                        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                        req.setTitle(safeName);
                        req.setDescription("E PRIME MUSIC");
                        req.setMimeType("audio/mpeg");
                        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "E-Prime Music/" + safeName);
                        dm.enqueue(req);
                        showToast("Downloading to Music/E-Prime Music");
                    }
                } catch (Exception e) {
                    showToast("Download failed");
                }
            }, "EPrimeMusicDownload").start();
        }

        private void downloadToUri(String urlString, Uri destination) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setRequestMethod("GET");
            c.connect();
            if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) {
                throw new Exception("HTTP " + c.getResponseCode());
            }
            try (InputStream in = c.getInputStream();
                 OutputStream out = context.getContentResolver().openOutputStream(destination)) {
                if (out == null) throw new Exception("Could not open output");
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
            } finally {
                c.disconnect();
            }
        }

        private String sanitizeFileName(String name) {
            String n = name == null ? "Unknown Song.mp3" : name;
            n = n.replaceAll("[\\/:*?\"<>|\\x00-\\x1F]", "");
            n = n.replaceAll("[. ]+$", "").trim();
            if (n.isEmpty()) n = "Unknown Song.mp3";
            if (!n.toLowerCase().endsWith(".mp3")) n += ".mp3";
            return n;
        }

        private void showToast(String message) {
            if (context instanceof Activity) {
                ((Activity) context).runOnUiThread(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (current != null && current.get() == this) current.clear();
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
