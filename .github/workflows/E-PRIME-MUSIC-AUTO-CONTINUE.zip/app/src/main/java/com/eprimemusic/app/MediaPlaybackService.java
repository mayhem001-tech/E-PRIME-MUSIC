package com.eprimemusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import androidx.media.session.MediaButtonReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

public class MediaPlaybackService extends Service {
    public static final String ACTION_UPDATE = "com.eprimemusic.app.UPDATE";
    public static final String ACTION_STOP = "com.eprimemusic.app.STOP";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ARTIST = "artist";
    public static final String EXTRA_PLAYING = "playing";

    private static final String CHANNEL_ID = "eprime_music_playback";
    private static final int NOTIFICATION_ID = 4107;
    private MediaSessionCompat session;
    private String title = "E PRIME MUSIC";
    private String artist = "Nothing playing";
    private boolean playing = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();

        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        session = new MediaSessionCompat(this, "EPrimeMusic");
        session.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { MainActivity.mediaCommand("play"); }
            @Override public void onPause() { MainActivity.mediaCommand("pause"); }
            @Override public void onSkipToNext() { MainActivity.mediaCommand("next"); }
            @Override public void onSkipToPrevious() { MainActivity.mediaCommand("prev"); }
            @Override public void onStop() { MainActivity.mediaCommand("pause"); }
        });
        session.setActive(true);
        session.setSessionActivity(content);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("play".equals(action) || "pause".equals(action) || "next".equals(action) || "prev".equals(action)) {
                MainActivity.mediaCommand(action);
                return START_STICKY;
            }
            if (ACTION_STOP.equals(action)) {
                MainActivity.mediaCommand("pause");
                stopForeground(false);
                return START_STICKY;
            }
        }
        if (intent != null && ACTION_UPDATE.equals(intent.getAction())) {
            title = intent.getStringExtra(EXTRA_TITLE);
            artist = intent.getStringExtra(EXTRA_ARTIST);
            playing = intent.getBooleanExtra(EXTRA_PLAYING, false);
        }
        if (title == null) title = "E PRIME MUSIC";
        if (artist == null) artist = "E PRIME MUSIC";
        updateMediaSession();
        startForeground(NOTIFICATION_ID, buildNotification());
        return START_STICKY;
    }

    private void updateMediaSession() {
        session.setMetadata(new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "E PRIME MUSIC")
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, 0)
                .build());

        long state = playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
        long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE |
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                PlaybackStateCompat.ACTION_PLAY_PAUSE;
        session.setPlaybackState(new PlaybackStateCompat.Builder()
                .setActions(actions).setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f).build());
    }

    private Notification buildNotification() {
        Intent prev = new Intent(this, MediaPlaybackService.class);
        prev.setAction("prev");
        PendingIntent pPrev = PendingIntent.getService(this, 1, prev,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent play = new Intent(this, MediaPlaybackService.class);
        play.setAction(playing ? "pause" : "play");
        PendingIntent pPlay = PendingIntent.getService(this, 2, play,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent next = new Intent(this, MediaPlaybackService.class);
        next.setAction("next");
        PendingIntent pNext = PendingIntent.getService(this, 3, next,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MediaPlaybackService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent pStop = PendingIntent.getService(this, 4, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.e_prime_music_logo)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.e_prime_music_logo))
                .setContentTitle(title)
                .setContentText(artist)
                .setContentIntent(session.getController().getSessionActivity())
                .setOngoing(playing)
                .setOnlyAlertOnce(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(new NotificationCompat.Action(R.drawable.e_prime_music_logo, "Previous", pPrev))
                .addAction(new NotificationCompat.Action(
                        R.drawable.e_prime_music_logo, playing ? "Pause" : "Play", pPlay))
                .addAction(new NotificationCompat.Action(R.drawable.e_prime_music_logo, "Next", pNext))
                .setStyle(new MediaStyle().setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Music playback",
                    NotificationManager.IMPORTANCE_LOW);
            c.setDescription("E PRIME MUSIC playback controls");
            c.setShowBadge(false);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }


    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep the foreground media service alive when the app is swiped away.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        if (session != null) { session.setActive(false); session.release(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

}